﻿#include "initwindow.h"
#include <QDebug>
#include "linechartblockview.h"
#include "testthread.h"
#include "stratgymanegeitem.h"
void InitWindow::create_chart(){
    LineChartBlockView* l1 = new LineChartBlockView(QString("test1"),20,20,20);
    LineChartBlockView* l2 = new LineChartBlockView(QString("test2"),20,20,20);
    LineChartBlockView* l3 = new LineChartBlockView(QString("test3"),20,20,20);
    LineChartBlockView* l4 = new LineChartBlockView(QString("test4"),20,20,20);
    LineChartBlockView* l5 = new LineChartBlockView(QString("test5"),20,20,20);
    LineChartBlockView* l6 = new LineChartBlockView(QString("test6"),20,20,20);
    LineChartBlockView* l7 = new LineChartBlockView(QString("test7"),20,20,20);
    LineChartBlockView* l8 = new LineChartBlockView(QString("test8"),20,20,20);
    LineChartBlockView* l9 = new LineChartBlockView(QString("test9"),20,20,20);
    l1->add_lineseries("line1",QPen(QBrush(Qt::red),2,Qt::SolidLine),QColor(255,255,255));
    //l1->AddLineSeries("line2",QPen(QBrush(Qt::blue),2,Qt::SolidLine),QColor(255,255,255));
    //l1->AddLineSeries("line3",QPen(QBrush(Qt::yellow),2,Qt::SolidLine),QColor(255,255,255));
    l2->add_lineseries("line1",QPen(QBrush(Qt::red),2,Qt::SolidLine),QColor(255,255,255));
    l3->add_lineseries("line1",QPen(QBrush(Qt::red),2,Qt::SolidLine),QColor(255,255,255));
    l4->add_lineseries("line1",QPen(QBrush(Qt::red),2,Qt::SolidLine),QColor(255,255,255));
    l5->add_lineseries("line1",QPen(QBrush(Qt::red),2,Qt::SolidLine),QColor(255,255,255));
    l6->add_lineseries("line1",QPen(QBrush(Qt::red),2,Qt::SolidLine),QColor(255,255,255));
    l7->add_lineseries("line1",QPen(QBrush(Qt::red),2,Qt::SolidLine),QColor(255,255,255));
    l8->add_lineseries("line1",QPen(QBrush(Qt::red),2,Qt::SolidLine),QColor(255,255,255));
    l9->add_lineseries("line1",QPen(QBrush(Qt::red),2,Qt::SolidLine),QColor(255,255,255));
    QGridLayout* data_page_layout = qobject_cast<QGridLayout*>(data_page->layout());
    data_page_layout->addWidget(l1,0,0,1,1);
    data_page_layout->addWidget(l2,0,1,1,1);
    data_page_layout->addWidget(l3,0,2,1,1);
    data_page_layout->addWidget(l4,1,0,1,1);
    data_page_layout->addWidget(l5,1,1,1,1);
    data_page_layout->addWidget(l6,1,2,1,1);
    data_page_layout->addWidget(l7,2,0,1,1);
    data_page_layout->addWidget(l8,2,1,1,1);
    data_page_layout->addWidget(l9,2,2,1,1);
    Pages->setCurrentIndex(0);

    TestThread* t1 = new TestThread(l1,0);
    t1->start();
}
void InitWindow::init_data_page(){
    create_chart();
}
void InitWindow::init_order_page(){

}
void InitWindow::init_account_page(){

}
void InitWindow::init_strategy_page(){
    QLabel *label = new QLabel(u8"策略1");
    label->setMaximumWidth(200);
    label->setMaximumHeight(36);
    label->setStyleSheet("color:rgb(255,255,255);background-color:rgb(255,255,255)");
    ((QGridLayout*)(strategy_page->layout()))->addWidget(label);

}
void InitWindow::on_enlarge(LineChartBlockView* view){
    QGridLayout* data_page_layout = qobject_cast<QGridLayout*>(data_page->layout());
}
InitWindow::InitWindow()
{
    //this->setMinimumSize(1600,960);
    this->setStyleSheet(QStringLiteral("background-color:rgb(20,22,39);"));
    MainView = new QHBoxLayout();
    MenuLayout = new QVBoxLayout();
    Menu_Page = new QLabel();//MenuLayout和PageLayout分隔
    PageLayout = new QVBoxLayout();
    Menu_Page->setMinimumWidth(1);
    Menu_Page->setMaximumWidth(1);
    Menu_Page->setStyleSheet(QStringLiteral("background-color:rgb(255,255,255);"));
    MainView->addLayout(MenuLayout);
    MainView->addWidget(Menu_Page);
    MainView->addLayout(PageLayout);
    label_5 = new QLabel();
    label_5->setMinimumHeight(1);
    label_5->setMaximumHeight(1);
    label_5->setStyleSheet(QStringLiteral("background-color:rgb(255,255,255);"));
    label_6 = new QLabel();
    label_6->setMinimumHeight(1);
    label_6->setMaximumHeight(1);
    label_6->setStyleSheet(QStringLiteral("background-color:rgb(255,255,255);"));
    label_7 = new QLabel();
    label_7->setMinimumHeight(1);
    label_7->setMaximumHeight(1);
    label_7->setStyleSheet(QStringLiteral("background-color:rgb(255,255,255);"));
    title = new QLabel();
    title->setMinimumHeight(64);
    title->setMaximumHeight(64);
    title->setFont(QFont("Arial Black",20,QFont::Bold));
    title->setText("HTFS");
    title->setStyleSheet(QStringLiteral("background-color: rgb(40,43, 59);color: rgb(255, 255, 255);"));
    account_manage = new QPushButton(u8"账号管理");
    account_manage->setStyleSheet(QStringLiteral("background-color: rgb(29,31, 49);color: rgb(255, 255, 255);"));
    data_view = new QPushButton(u8"实时数据");
    data_view->setStyleSheet(QStringLiteral("background-color: rgb(29,31, 49);color: rgb(255, 255, 255);"));
    strategy_manage = new QPushButton(u8"策略配置");
    strategy_manage->setStyleSheet(QStringLiteral("background-color: rgb(29,31, 49);color: rgb(255, 255, 255);"));
    order_manage = new QPushButton(u8"订单管理");
    order_manage->setStyleSheet(QStringLiteral("background-color: rgb(29,31, 49);color: rgb(255, 255, 255);"));
    verticalSpacer = new QSpacerItem(20,40,QSizePolicy::Minimum, QSizePolicy::Expanding);

    MenuLayout->addWidget(title);
    MenuLayout->addWidget(data_view);
    MenuLayout->addWidget(label_5);
    MenuLayout->addWidget(strategy_manage);
    MenuLayout->addWidget(label_6);
    MenuLayout->addWidget(account_manage);
    MenuLayout->addWidget(label_7);
    MenuLayout->addWidget(order_manage);
    MenuLayout->addSpacerItem(verticalSpacer);

    Pages = new QStackedWidget();
    Pages->setStyleSheet(QStringLiteral("background-color: rgb(40,43, 59);"));
    data_page = new QWidget();
    data_page->setLayout(new QGridLayout());
    strategy_page = new QWidget();
    strategy_page->setLayout(new QGridLayout());
    account_page = new QWidget();
    account_page->setLayout(new QGridLayout());
    order_page = new QWidget();
    order_page->setLayout(new QGridLayout());
    Pages->addWidget(data_page);
    Pages->addWidget(strategy_page);
    Pages->addWidget(account_page);
    Pages->addWidget(order_page);
    label_10 = new QLabel();
    workspace = new QLabel(u8"行情数据");
    workspace->setFont(QFont("Arial Black",16,QFont::Bold));
    workspace->setAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
    workspace->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);background-color: rgb(40, 43, 59);"));

    PageLayout->addWidget(workspace);
    PageLayout->addWidget(Pages);
    PageLayout->addWidget(label_10);

    Pages->setCurrentIndex(0);

    connect(data_view, &QPushButton::clicked, this, &InitWindow::on_data_view_clicked);
    connect(strategy_manage, &QPushButton::clicked, this, &InitWindow::on_strategy_manage_clicked);
    connect(account_manage, &QPushButton::clicked, this, &InitWindow::on_account_manage_clicked);
    connect(order_manage, &QPushButton::clicked, this, &InitWindow::on_order_manage_clicked);

    init_data_page();
    init_strategy_page();

    this->setLayout(MainView);
}


void InitWindow::on_data_view_clicked(){
    Pages->setCurrentIndex(0);
    workspace->setText(u8"行情数据");
}

void InitWindow::on_strategy_manage_clicked(){
    Pages->setCurrentIndex(1);
    workspace->setText(u8"策略配置");
}

void InitWindow::on_account_manage_clicked(){
    Pages->setCurrentIndex(2);
    workspace->setText(u8"账户管理");
}

void InitWindow::on_order_manage_clicked(){
    Pages->setCurrentIndex(3);
    workspace->setText(u8"订单管理");
}
