#include "linechartblockview.h"
#include "testthread.h"

LineChartBlockView::LineChartBlockView(QString name,int _maxX,int _maxY,int _maxSize)
{
    maxX = _maxX;
    maxY = _maxY;
    maxSize = _maxSize;
    datanum = 0;
    data = new QList<double>();
    chart = new QChart();

    lines = new QList<QLineSeries*>();

    //chart->setTheme(QChart::ChartThemeBlueCerulean);//设置系统主题
    //chart->setAnimationOptions(QChart::SeriesAnimations);//设置启用或禁用动画
    chart->setBackgroundBrush(QBrush(QColor(20,22,39)));//设置背景色,主题和背景二选一
    //chart->setDropShadowEnabled(true);//是否背景阴影
    //chart->setLocalizeNumbers(true);//数字是否本地化
    chart->legend()->hide();//legend是否显示，show和hide

    chart->setTitle(name);//设置标题

    chart->setTitleBrush(QBrush(QColor(255,170,255)));//设置标题Brush
    chart->setTitleFont(QFont("微软雅黑",12));//设置标题字体

    this->setChart(chart);
    this->setRenderHint(QPainter::Antialiasing);
    //this->show();
}
void LineChartBlockView::add_lineseries(QString name,QPen linePen,QColor pointLabelColor){
    QLineSeries *line = new QLineSeries();
    line->setName(name);    //设置线条名称
    //line->setColor(lineColor);     //设置线条颜色
    //line->setPen(QPen(QBrush(Qt::red),2,Qt::SolidLine));
    line->setPen(linePen);
    line->setVisible(true);    //线条是否可视
    line->setPointsVisible(true);//点是否可视
    line->setPointLabelsVisible(false);//点标签是否可视
    line->setPointLabelsColor(pointLabelColor);    //设置点标签颜色
    line->setPointLabelsFont(QFont("微软雅黑"));       //点标签字体
    line->setPointLabelsFormat("(@xPoint,@yPoint)");   //点标签格式
    line->setPointLabelsClipping(true);       //是否切割边缘点标签，默认为true

    connect(line, &QScatterSeries::hovered, this, &LineChartBlockView::on_mouse_entered_line);//设置鼠标移入事件


    lines->append(line);

    if(hasAxis){
        line->append(0,0);
        line->append(0,20);
        chart->addSeries(line);//添加线到QChart上
        chart->createDefaultAxes();
        line->clear();
    }
    else{
        line->append(0,0);
        line->append(0,20);
        chart->addSeries(line);//添加线到QChart上
        chart->createDefaultAxes();
        chart->axisX()->setRange(0,20);
        chart->axisY()->setRange(0,20);
        line->clear();
        hasAxis = true;
    }

}

void LineChartBlockView::update_line(qreal x, qreal y, int index){

    QLineSeries* target = lines->at(index);
    if(datanum>=20){
        target->remove(0);
        chart->axisX()->setRange(datanum-19, datanum+1);
    }
    *target << QPointF(x, y);
    chart->update();
}

void LineChartBlockView::data_added(){
    datanum++;
}

void LineChartBlockView::on_mouse_entered_line(const QPointF &point, bool state){
    QLineSeries* line = qobject_cast<QLineSeries *>(sender());
    if(state){

        line->setPen(QPen(line->pen().brush(),4,Qt::SolidLine));
    }
    else{
        line->setPen(QPen(line->pen().brush(),2,Qt::SolidLine));
    }
    chart->update();
}

void LineChartBlockView::mouseReleaseEvent(QMouseEvent *event){
    emit enlarge(this);
    //qDebug()<<"aaa";
}
