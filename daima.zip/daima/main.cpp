﻿#include "mainwindow.h"
#include <QApplication>
#include "initwindow.h"
#include "nontitle.h"
#include "stratgymanegeitem.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    //MainWindow w;
    //w.show();
    //stratgymanegeitem* s = new stratgymanegeitem();
    //s->show();
    //InitWindow* i = new InitWindow();

    nontitle* n = new nontitle();
    //n->setFixedSize(400,480);
    n->setContent(new InitWindow());
    n->show();

    //i->show();
    return a.exec();
}
