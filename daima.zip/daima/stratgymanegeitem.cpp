﻿#include "stratgymanegeitem.h"
#include<QFile>
#include<QDataStream>
#include<QDebug>
#include<QDir>

stratgymanegeitem::stratgymanegeitem()
{
    r = 0;
    q = 0;
    futures_commission = 0;
    futures_cost = 0;
    stock_commission = 0;
    stock_cost = 0;
    stamp_duty = 0;
    stock_impact_cost = 0;
    stock_index_error = 0;
    borrowing_cost = 0;

    title = new editlabel();

    split_line_1 = new QLabel();
    split_line_1->setMaximumHeight(1);
    split_line_1->setStyleSheet(QStringLiteral("background-color:rgb(255,255,255);"));

    split_line_2 = new QLabel();
    split_line_2->setMaximumHeight(1);
    split_line_2->setStyleSheet(QStringLiteral("background-color:rgb(255,255,255);"));

    label_r = new QLabel(u8"年利率");
    label_q = new QLabel(u8"年红利");
    label_futures_commission = new QLabel(u8"期货双边手续费");
    label_futures_cost = new QLabel(u8"期货买卖冲击成本");
    label_stock_commission = new QLabel(u8"股票买卖双边手续费");
    label_stock_cost = new QLabel(u8"股票买卖冲击成本");
    label_stamp_duty = new QLabel(u8"股票交易印花税");
    label_stock_impact_cost = new QLabel(u8"股票买卖冲击成本");
    label_stock_index_error = new QLabel(u8"股票指数跟踪误差");
    label_borrowing_cost = new QLabel(u8"借贷利差成本");

    lineedit_r = new QLineEdit();
    lineedit_q = new QLineEdit();
    lineedit_futures_commission = new QLineEdit();
    lineedit_futures_cost = new QLineEdit();
    lineedit_stock_commission = new QLineEdit();
    lineedit_stock_cost = new QLineEdit();
    lineedit_stamp_duty = new QLineEdit();
    lineedit_stock_impact_cost = new QLineEdit();
    lineedit_stock_index_error = new QLineEdit();
    lineedit_borrowing_cost = new QLineEdit();

    label_r->setMinimumWidth(180);
    label_q->setMinimumWidth(180);
    label_futures_commission->setMinimumWidth(180);
    label_futures_cost->setMinimumWidth(180);
    label_stock_commission->setMinimumWidth(180);
    label_stock_cost->setMinimumWidth(180);
    label_stamp_duty->setMinimumWidth(180);
    label_stock_impact_cost->setMinimumWidth(180);
    label_stock_index_error->setMinimumWidth(180);
    label_borrowing_cost->setMinimumWidth(180);

    vlayout = new QVBoxLayout();
    hlayout_r = new QHBoxLayout();
    hlayout_r->addWidget(label_r);
    hlayout_r->addWidget(lineedit_r);


    hlayout_q = new QHBoxLayout();
    hlayout_q->addWidget(label_q);
    hlayout_q->addWidget(lineedit_q);

    hlayout_futures_commission = new QHBoxLayout();
    hlayout_futures_commission->addWidget(label_futures_commission);
    hlayout_futures_commission->addWidget(lineedit_futures_commission);

    hlayout_futures_cost = new QHBoxLayout();
    hlayout_futures_cost->addWidget(label_futures_cost);
    hlayout_futures_cost->addWidget(lineedit_futures_cost);

    hlayout_stock_commission = new QHBoxLayout();
    hlayout_stock_commission->addWidget(label_stock_commission);
    hlayout_stock_commission->addWidget(lineedit_stock_commission);

    hlayout_stock_cost = new QHBoxLayout();
    hlayout_stock_cost->addWidget(label_stock_cost);
    hlayout_stock_cost->addWidget(lineedit_stock_cost);

    hlayout_stamp_duty = new QHBoxLayout();
    hlayout_stamp_duty->addWidget(label_stamp_duty);
    hlayout_stamp_duty->addWidget(lineedit_stamp_duty);

    hlayout_stock_impact_cost = new QHBoxLayout();
    hlayout_stock_impact_cost->addWidget(label_stock_impact_cost);
    hlayout_stock_impact_cost->addWidget(lineedit_stock_impact_cost);

    hlayout_stock_index_error = new QHBoxLayout();
    hlayout_stock_index_error->addWidget(label_stock_index_error);
    hlayout_stock_index_error->addWidget(lineedit_stock_index_error);

    hlayout_borrowing_cost = new QHBoxLayout();
    hlayout_borrowing_cost->addWidget(label_borrowing_cost);
    hlayout_borrowing_cost->addWidget(lineedit_borrowing_cost);

    vlayout->addWidget(title);
    vlayout->addWidget(split_line_1);
    vlayout->addLayout(hlayout_r);
    vlayout->addLayout(hlayout_q);
    vlayout->addLayout(hlayout_futures_commission);
    vlayout->addLayout(hlayout_futures_cost);
    vlayout->addLayout(hlayout_stock_commission);
    vlayout->addLayout(hlayout_stock_cost);
    vlayout->addLayout(hlayout_stamp_duty);
    vlayout->addLayout(hlayout_stock_impact_cost);
    vlayout->addLayout(hlayout_stock_index_error);
    vlayout->addLayout(hlayout_borrowing_cost);
    vlayout->addWidget(split_line_2);

    confirm = new QPushButton(u8"确定");
    confirm->setStyleSheet("background-color: rgb(255, 200, 64);border-radius: 5px;color: rgb(47,53,46);font: 14pt '黑体';");
    confirm->setMinimumHeight(30);
    confirm->setMinimumWidth(120);
    confirm->setMaximumWidth(160);


    vlayout->addWidget(confirm,0,Qt::AlignCenter);

    this->setLayout(vlayout);

    setFixedSize(400, 460);

    this->setStyleSheet(QStringLiteral("background-color:rgb(44,44,44);color:rgb(255,255,255);font: 12pt '黑体';"));


    connect(confirm,SIGNAL(clicked()),this,SLOT(on_confirm_clicked()));
}

void stratgymanegeitem::on_confirm_clicked(){
    QDir dir;
    if(!dir.exists("./stratgies")){
        dir.mkdir("./stratgies");
    }
    QFile file("./stratgies/stratgy_1");
    file.open(QIODevice::WriteOnly);

    QDataStream ds(&file);

    r = lineedit_r->text().toDouble();
    q = lineedit_q->text().toDouble();
    futures_commission = lineedit_futures_commission->text().toDouble();
    futures_cost = lineedit_futures_cost->text().toDouble();
    stock_commission = lineedit_stock_commission->text().toDouble();
    stock_cost = lineedit_stock_cost->text().toDouble();
    stamp_duty = lineedit_stamp_duty->text().toDouble();
    stock_impact_cost = lineedit_stock_impact_cost->text().toDouble();
    stock_index_error = lineedit_stock_index_error->text().toDouble();
    borrowing_cost = lineedit_borrowing_cost->text().toDouble();

    ds<<title->text();
    ds<<r;
    ds<<q;
    ds<<futures_commission;
    ds<<futures_cost;
    ds<<stock_commission;
    ds<<stock_cost;
    ds<<stamp_duty;
    ds<<stock_impact_cost;
    ds<<stock_index_error;
    ds<<borrowing_cost;

    file.close();
}
