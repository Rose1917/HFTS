#ifndef INITWINDOW_H
#define INITWINDOW_H
#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "linechartblockview.h"

class InitWindow : public QWidget
{
    Q_OBJECT
public:
    QHBoxLayout *MainView;
    QVBoxLayout *MenuLayout;
    QLabel *title;
    QPushButton *data_view;
    QLabel *label_5;
    QPushButton *strategy_manage;
    QLabel *label_6;
    QPushButton *account_manage;
    QLabel *label_7;
    QPushButton *order_manage;
    QSpacerItem *verticalSpacer;
    QLabel *Menu_Page;
    QVBoxLayout *PageLayout;
    QLabel *workspace;
    QStackedWidget *Pages;
    QWidget *data_page;
    QWidget *strategy_page;
    QWidget *account_page;
    QWidget *order_page;
    QLabel *label_10;
    InitWindow();
private slots:

    void on_data_view_clicked();

    void on_strategy_manage_clicked();

    void on_account_manage_clicked();

    void on_order_manage_clicked();

    void on_enlarge(LineChartBlockView* view);

private:
    void create_chart();
    void init_data_page();

    void init_strategy_page();
    void init_account_page();
    void init_order_page();
};

#endif // INITWINDOW_H
