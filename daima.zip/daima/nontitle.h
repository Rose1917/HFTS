﻿#ifndef NONTITLE_H
#define NONTITLE_H

#include<QWidget>
#include<QPushButton>
#include<QBoxLayout>
#include<QMouseEvent>
#include<QPainter>
#include<QStyleOption>
class nontitle : public QWidget
{
public:
    nontitle();

    virtual void mouseMoveEvent(QMouseEvent *event);
    virtual void mousePressEvent(QMouseEvent *event);
    virtual void mouseReleaseEvent(QMouseEvent *event);
    virtual void paintEvent(QPaintEvent *event);

    void setContent(QWidget* w);
private:
    bool isPressed;
    QPoint startPos;

    QPushButton* minimizeButton;
    QPushButton* closeButton;
    QHBoxLayout* titleLayout;
    QVBoxLayout* layout;
};

#endif // NONTITLE_H
